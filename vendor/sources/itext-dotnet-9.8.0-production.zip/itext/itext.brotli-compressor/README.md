# Brotli Compression Strategy for iText

## Overview

This module provides a Brotli compression implementation for PDF streams in iText. Brotli is a modern compression algorithm that typically provides better compression ratios than traditional Flate/Deflate compression, especially for text-heavy content.

## Important Notice

**EXPERIMENTAL FEATURE**: Brotli compression for PDF streams is currently experimental and is not part of the official PDF specification. PDF documents compressed using Brotli may not be compatible with other PDF processors or readers. Use this feature with caution and only when you control both the generation and consumption of the PDF documents.

## Features

- Implementation of iText's `IStreamCompressionStrategy` interface
- Automatic compression level mapping from iText's 0-9 scale to Brotli's 0-4 scale
- Better compression ratios compared to Flate compression for most text content
- Seamless integration with iText's PDF generation workflow

## Requirements

- iText 9.5.0 or later

## Installation


`brotli-compressor` is experimental so the artifacts are only available on iText's artifactory.

 You can add it as a custom NuGet repository to Visual Studio. In the NuGet Package Manager, go to the settings and add the following URL as a package source: https://repo.itextsupport.com/api/nuget/nuget. You can also browse the iText Artifactory server and download NuGet packages manually.

Add the following dependency to your .NET project:

```bash

dotnet add package itext.brotli-compressor --version ${itext.version.bigger.then.9.5.0}
```

## Usage

To use Brotli compression for PDF streams, register the `BrotliStreamCompressionStrategy` with your PDF document:

```C#

// Create a PDF document with Brotli compression
DocumentProperties properties = new DocumentProperties();
properties.RegisterDependency(IStreamCompressionStrategy.class, new BrotliStreamCompressionStrategy());
PdfDocument pdfDoc = new PdfDocument(new PdfWriter(outputStream), properties);

// Continue with normal PDF generation
// All streams will be compressed using Brotli
```

## Compression Levels

The Brotli compression strategy automatically maps iText compression levels to Brotli levels:

- iText levels: 0 (no compression) to 9 (best compression)
- Brotli C# levels: 0 to 4
- Mapping formula: `brotliLevel = round(iTextLevel * (11.0 / 4.0))`

You can set the compression level on the PDF writer:

```C#

DocumentProperties properties = new DocumentProperties();
properties.RegisterDependency(IStreamCompressionStrategy.class, new BrotliStreamCompressionStrategy());

PdfWriter writer = new PdfWriter(outputStream);
writer.SetCompressionLevel(9); // Maximum compression
PdfDocument pdfDoc = new PdfDocument(writer, properties);

```


## Decompression

Supported out of the box in the iText kernel module

The filter supports:
- Standard Brotli decompression
- Optional Brotli dictionary streams (specified via decode parameters)
- Memory limits awareness through iText's MemoryLimitsAwareHandler


## Compatibility Warning

PDF documents using Brotli compression (`/BrotliDecode` filter) are currently not compliant with the official PDF specification (ISO 32000). These documents may:

- Fail to open in standard PDF readers (Adobe Acrobat, Preview, etc.)
- Not render correctly in web browsers
- Be rejected by PDF validation tools
- Not be processable by third-party PDF libraries

This compression method should only be used in controlled environments where:
- You generate and consume the PDF documents within your own system
- You have verified compatibility with your specific PDF processing pipeline
- You can handle potential incompatibilities with external tools

