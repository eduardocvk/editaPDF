/*
This file is part of the iText (R) project.
Copyright (c) 1998-2026 Apryse Group NV
Authors: Apryse Software.

This program is offered under a commercial and under the AGPL license.
For commercial licensing, contact us at https://itextpdf.com/sales.  For AGPL licensing, see below.

AGPL licensing:
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/
using System;
using System.Collections.Generic;
using iText.Commons.Utils;

namespace iText.Commons.Actions {
    /// <summary>Class which contains open source product name constants.</summary>
    public sealed class ProductNameConstant {
        /// <summary>itext-core constant.</summary>
        public const String ITEXT_CORE = "itext-core";

        /// <summary>itext-core sign module constant.</summary>
        public const String ITEXT_CORE_SIGN = "itext-core-sign";

        /// <summary>pdfhtml constant.</summary>
        public const String PDF_HTML = "pdfHtml";

        /// <summary>pdfsweep constant.</summary>
        public const String PDF_SWEEP = "pdfSweep";

        /// <summary>pdfocr-tesseract4 constant.</summary>
        public const String PDF_OCR_TESSERACT4 = "pdfOcr-tesseract4";

        /// <summary>pdfocr-onnxtr constant.</summary>
        [System.ObsoleteAttribute(@"in favour of PDF_OCR_ONNX")]
        public const String PDF_OCR_ONNXTR = "pdfOcr-onnxtr";

        /// <summary>pdfocr-onnx constant.</summary>
        public const String PDF_OCR_ONNX = "pdfOcr-onnx";

        /// <summary>set of product names.</summary>
        public static readonly ICollection<String> PRODUCT_NAMES = JavaCollectionsUtil.UnmodifiableSet(new HashSet
            <String>(JavaUtil.ArraysAsList(iText.Commons.Actions.ProductNameConstant.ITEXT_CORE, iText.Commons.Actions.ProductNameConstant
            .PDF_HTML, iText.Commons.Actions.ProductNameConstant.PDF_SWEEP, iText.Commons.Actions.ProductNameConstant
            .PDF_OCR_TESSERACT4, iText.Commons.Actions.ProductNameConstant.PDF_OCR_ONNX)));

        private ProductNameConstant() {
        }
    }
}
