/*
This file is part of the iText (R) project.
Copyright (c) 1998-2026 Apryse Group NV
Authors: Apryse Software.

This program is offered under a commercial and under the AGPL license.
For commercial licensing, contact us at https://itextpdf.com/sales.  For AGPL licensing, see below.

AGPL licensing:
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.
*/
using System;
using iText.Commons.Exceptions;

namespace iText.Barcodes.Exceptions {
    /// <summary>
    /// A base class which covers the range of exceptions which may occur when encoding a barcode using
    /// the Writer framework.
    /// </summary>
    public sealed class WriterException : ITextException {
        private const long serialVersionUID = -9185997341735096449L;

        /// <summary>Creates a WriterException.</summary>
        public WriterException()
            : base() {
        }

        /// <summary>Creates a WriterException with a message.</summary>
        /// <param name="message">message of the exception</param>
        public WriterException(String message)
            : base(message) {
        }

        /// <summary>Creates a WriterException with a specified detail message and a cause.</summary>
        /// <param name="message">the detail message, which provides additional information about the exception</param>
        /// <param name="cause">the cause of the exception</param>
        public WriterException(String message, Exception cause)
            : base(message, cause) {
        }
    }
}
